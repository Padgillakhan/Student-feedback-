<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>

        .container {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        a{
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container-fluid bg-dark">
        <div class="container">
            <div class="col-md-6">
                <div class="card">
                <?php
                    session_start();
                    $con = mysqli_connect('localhost', 'root', '', 'practice01');

                    if (isset($_POST["login"])) {
                        $email = $_POST['email'];
                        $password = $_POST['password'];
                        $captcha = $_POST['captcha'];

                 
                        if ($captcha == $_SESSION['captcha']) {
                            $sql = mysqli_query($con, "SELECT * FROM `register` WHERE `email`='$email' AND `password`='$password'");
                            $num_row = mysqli_num_rows($sql);
                            if ($num_row > 0) {
                                $row = mysqli_fetch_assoc($sql);
                                $_SESSION['id'] = $row['id'];
                                $_SESSION['email'] = $row['email'];
                                header("Location: feedback.php");
                            } else {
                                echo '<div class="alert alert-danger" role="alert">Invalid email or password</div>';
                            }
                        } else {
                            echo '<div class="alert alert-danger" role="alert">Please enter a valid captcha</div>';
                        }
                    }
                ?>

                    <div class="card-header text-center">
                        <h3>Login</h3>
                    </div>
                    <div class="card-body">
                        <form action="login.php" method="POST">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="row">

                            <div class="col-md-6">
                                <label for="captcha" class="form-label">Captcha</label>
                                <input type="text" name="captcha" class="form-control" placeholder="Enter Your Captcha">
                            </div>
                             
                                <div class="col-md-6" style="margin-top:34px;">
                                    
                                    <img src="capcha.php" alt="Captcha" class="img-fluid">
                                </div>
                            </div><br>
                            <div class="d-grid">
                                <button type="submit" name="login" class="btn btn-primary">Login</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer text-center">
                        <small>Don't have an account? <a href="register.php">Register here</a></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
