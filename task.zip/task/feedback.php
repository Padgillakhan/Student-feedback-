<?php
session_start();
$con = mysqli_connect('localhost', 'root', '', 'practice01');
if (!isset($_SESSION['id'])) {
    echo "<script>window.location.href='login.php'</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback page </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .html,body{
            margin: 0%;
            padding: 0%;
            background-color:black;
        }
        .container {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>
    <div class="container-fluid bg-dark" >
        <div class="container ">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h3>Feedback Form</h3>
                    </div>
                    <?php

                        $id = $_SESSION['id'];
                        $query = "SELECT * FROM `register` WHERE `id`='$id'";
                        $result = mysqli_query($con, $query);

                        if ($result && mysqli_num_rows($result) > 0) {
                            $user = mysqli_fetch_assoc($result);
                        } else {
                            echo '<div class="alert alert-danger" role="alert">User not found.</div>';
                            exit();
                        }

                        if (isset($_POST["submit"])) {
                            $checkFeedbackQuery = "SELECT * FROM `feedback` WHERE `name`='$user[name]' AND `course`='$user[course]'";
                            $checkResult = mysqli_query($con, $checkFeedbackQuery);

                            if (mysqli_num_rows($checkResult) > 0) {
                                echo '<div class="alert alert-warning" role="alert">You have already submitted feedback for this course. <a href="logout.php" class="sm-btn btn-primary">Logout</a></div>';
                            } else {
                                $name = $_POST['name'];
                                $course = $_POST['course'];
                                $semester = $_POST['semester'];
                                $teaching_quality = $_POST['teaching_quality'];
                                $course_material = $_POST['course_material'];
                                $lab_facilities = $_POST['lab_facilities'];
                                $overall_experience = $_POST['overall_experience'];
                                $message = $_POST['message'];
                                $date = $_POST['date'];

                                $insert = mysqli_query($con, "INSERT INTO `feedback`(`name`, `course`, `semester`, `teaching_quality`, `course_material`, `lab_facilities`, `overall_experience`, `message`, `date`)
                                VALUES('$name','$course','$semester','$teaching_quality','$course_material','$lab_facilities','$overall_experience','$message','$date')");

                                if ($insert) {
                                    echo '<b>"Your feedback has been successfully submitted! Thank you for taking the time to share your thoughts. Your input is valuable and helps us improve. If you need to make any changes or have additional comments, please reach out to us." <a href="logout.php" class="sm-btn btn-primary">Logout</a></b>';
                                } else {
                                    echo '<div class="alert alert-danger" role="alert">Something went wrong, please try again later.</div>';
                                }
                            }
                        }
                    ?>

                    <div class="card-body">
                        <form method="post" class="row g-3 mt-3 mb-3">                        
                            <div class="col-md-6">
                                <label for="name" class="form-label">Name :</label>
                                <input type="text" name="name" class="form-control" value="<?php echo $user['name'];?>">
                            </div>
                            <div class="col-md-6">
                                <label for="date" class="form-label">Date :</label>
                                <input type="text" name="date" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                            </div> 
                            <div class="col-md-6">
                                <label for="course" class="form-label">Course :</label>
                                <input type="text" name="course" class="form-control" value="<?php echo $user['course'];?>">
                            </div>
                            <div class="col-md-6">
                                <label for="semester" class="form-label">semister :</label>
                                <input type="text" name="semester" class="form-control" value="<?php echo $user['semester'];?>">
                            </div><br>
                            <h4 class="text-center mb-4 mt-4"><u>Student Feedback</u></h4>
                            <div class="col-md-6 mb-3">
                                <label for="teaching_quality" class="form-label">How would you rate the overall quality of the course materials?:</label><br>
                                <input type="radio" name="teaching_quality" value="Poor" required> Poor
                                <input type="radio" name="teaching_quality" value="Medium" required> Medium
                                <input type="radio" name="teaching_quality" value="Good" required> Good
                                <input type="radio" name="teaching_quality" value="Excellent" required checked> Excellent
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="course_material" class="form-label">Was the course content relevant to your academic and professional goals?:</label><br>
                                <input type="radio" name="course_material" value="Poor" required> Poor
                                <input type="radio" name="course_material" value="Medium" required> Medium
                                <input type="radio" name="course_material" value="Good" required> Good
                                <input type="radio" name="course_material" value="Excellent" checked> Excellent
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="lab_facilities" class="form-label">How would you rate the instructor’s knowledge of the subject?:</label><br>
                                <input type="radio" name="lab_facilities" value="Poor" required> Poor
                                <input type="radio" name="lab_facilities" value="Medium" required> Medium
                                <input type="radio" name="lab_facilities" value="Good" required> Good
                                <input type="radio" name="lab_facilities" value="Excellent" checked> Excellent
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="overall_experience" class="form-label">How would you rate the instructor's engagement with students?:</label><br>
                                <input type="radio" name="overall_experience" value="Poor" required> Poor
                                <input type="radio" name="overall_experience" value="Medium" required> Medium
                                <input type="radio" name="overall_experience" value="Good" required> Good
                                <input type="radio" name="overall_experience" value="Excellent" checked> Excellent
                            </div>
                            <div class="col-md-12">
                                <label class="form-label" for="message">Other Feedback :</label>
                                <textarea class="form-control" name="message"  rows="3"  placeholder="Enter  some massage :"></textarea>
                            </div>
                            <div class="col-md-5">
                                <button type="submit" class="form-control"  name="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
