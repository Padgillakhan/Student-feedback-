<?php
// session_start();
// $rand_number = rand(11111, 99999);
// $_SESSION['code'] = $rand_number;
// $layer = imagecreatetruecolor(60, 30);
// $captcha_bg = imagecolorallocate($layer, 255, 160, 120);
// imagefill($layer, 0, 0, $captcha_bg);
// $captcha_text_color = imagecolorallocate($layer, 0, 0, 0);
// imagestring($layer, 5, 5, 5, $rand_number, $captcha_text_color);
// header('Content-Type: image/png');
// imagepng($layer);
// imagedestroy($layer);


// Create an image with the specified width and height
// $rand_number = rand(11111, 99999);
// $image = imagecreate(60, 30);
// $bg_color = imagecolorallocate($image, 255, 160, 120);
// $text_color = imagecolorallocate($image, 0, 0, 0);
// imagefilledrectangle($image, 0, 0, 100, 30, $bg_color);
// imagestring($image, 5, 5, 5, $rand_number, $text_color);




// header('Content-Type: image/png');
// imagepng($image);
// imagedestroy($image);

session_start();

// Generate a random number for CAPTCHA
$rand_number = rand(111111, 999999);
$_SESSION['captcha'] = $rand_number; // Store the CAPTCHA in session

// Create an image
$image = imagecreate(100, 30);
$bg_color = imagecolorallocate($image, 255, 160, 120);
$text_color = imagecolorallocate($image, 0, 0, 0);

// Add the random number to the image
imagestring($image, 5, 10, 5, $rand_number, $text_color);

// Output the image
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
?>

