<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .html,body{
            margin: 0%;
            padding: 0%;
            background-color:black;
        }
        .container {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        a{
            text-decoration: none;
        }
        
    </style>
</head>
<body>

    <div class="container-fluid bg-dark">
        <?php
            session_start();
            $con = mysqli_connect('localhost', 'root', '', 'practice01');

            if (isset($_POST["submit"])) {
                $name = $_POST['name'];
                $course = $_POST['course'];
                $semester = $_POST['semester'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $number = $_POST['number'];
                $captcha = $_POST['captcha'];


                if ($captcha == $_SESSION['captcha']) {
                    $check_email = mysqli_query($con, "SELECT * FROM `register` WHERE `email`='$email'");
                    
                    if (mysqli_num_rows($check_email) > 0) {
                        echo '<div class="alert alert-danger" role="alert">This email is already registered. Please use a different email.</div>';
                    }else {
                        $insert = mysqli_query($con, "INSERT INTO `register`(`name`, `course`, `semester`, `email`, `password`, `number`) 
                        VALUES ('$name', '$course', '$semester', '$email', '$password', '$number')");
                        if ($insert) {
                            echo "<script>window.location.href='login.php'</script>";
                        } else {
                            echo '<div class="alert alert-danger" role="alert">Error: ' . mysqli_error($con) . '</div>';
                        }
                    }
                }else {
                    echo '<div class="alert alert-danger" role="alert">Please enter a valid captcha</div>';
                }
            }
        ?>
        <div class="container ">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h3>Register</h3>
                    </div>
                    <div class="card-body">
                        <form method="post" class="row g-3 mt-3 mb-3">

                            <div class="col-md-6">
                                <label for="name" class="form-label">Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Enter Your name">
                            </div>
                            <div class="col-md-6">
                                <label  class="form-label" for="Couser">Select Course:</label>
                                <select name="course" class="form-control" >
                                    <option value="b.tech">B.Tech</option>
                                    <option value="m.tech">M.Tech</option>
                                    <option value="bsc">Bsc</option>
                                    <option value="bsc">Msc</option>
                                    <option value="bca">Bca</option>
                                    <option value="mca">Mca</option>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label  class="form-label" for="semister">Select semester:</label>
                                <select name="semester" class="form-control" >
                                    <option value="1st">1st semester </option>
                                    <option value="2nd">2nd semester </option>
                                    <option value="3rd">3rd semester </option>
                                    <option value="4th">4th semester </option>
                                    <option value="5th">5th semester </option>
                                    <option value="6th">6th semester </option>
                                    <option value="7th">7th semester </option>
                                    <option value="8th">8th semester </option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Enter Your email">
                            </div>

                            <div class="col-md-6">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Enter Your Password">
                            </div>

                            <div class="col-md-6">
                                <label for="number" class="form-label">Number</label>
                                <input type="number" name="number" class="form-control" placeholder="Enter Your Number">
                            </div>

                            <div class="col-md-6">
                                <label for="captcha" class="form-label">Captcha</label>
                                <input type="text" name="captcha" class="form-control" placeholder="Enter Your Captcha">
                            </div>

                            <div class="col-md-6" style="margin-top:50px;">
                                <img src="capcha.php" alt="Captcha" class="img-fluid"> <a href="<?php echo $_SERVER['PHP_SELF'];?>">Refresh captcha</a>
                            </div>


                            <div class="col-12">
                                <button type="submit" name="submit" class="btn btn-primary">Submit</button><br>
                               
                            </div>
                        </form>
                    </div>
                    <div class="card-footer text-center">
                        <small>Do you have an account? <a class="link" href="login.php">Login here</a></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
